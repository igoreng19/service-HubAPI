# ServiceHub API

**Aluno:** Igor Raphael Marques de Carvalho  
**Matrícula:** 2410918

API REST acadêmica para contratação de serviços, com usuários CLIENT e PROVIDER, ofertas, solicitações e avaliações. Inclui CRUD, PATCH, filtros, paginação, validações, documentação OpenAPI e testes automatizados.

## Execução rápida do pacote

Requer Java 21 ou superior e Maven para execução local. No Windows, abra **iniciar.cmd** na raiz do projeto para iniciar a partir do código-fonte. Alternativamente, use Docker Compose conforme a seção de execução. Swagger: `http://localhost:8080/swagger-ui.html`.

Para executar o código durante o desenvolvimento, instale **JDK 21** e **Maven 3.6.3+**:

```powershell
mvn spring-boot:run
```

Nesta máquina, `.executar.ps1` também encontra o JDK 21 e o Maven fornecidos pelo IntelliJ quando JAVA_HOME e Maven não estiverem configurados. Em outros computadores, configure JAVA_HOME e PATH.

## URLs

- Swagger UI: http://localhost:8080/swagger-ui.html
- OpenAPI JSON: http://localhost:8080/v3/api-docs
- Diagnóstico: http://localhost:8080/api/hello
- O caminho antigo `/api-docs` redireciona para `/v3/api-docs`.

O Swagger contém o nome do aluno, matrícula, versão v1.0.0, contato e licença de uso acadêmico. Não foi inventado um endereço de e-mail para o contato.

## Tecnologias e arquitetura

Java 21, Spring Boot 3.5.5, Maven, Spring Web MVC, Spring Data JPA, Hibernate, Bean Validation, Lombok, Flyway, H2, PostgreSQL, Springdoc OpenAPI 2.8.9, Spring Security, JWT HS256, Spring for GraphQL, JUnit e Spring Boot Test/MockMvc. Senhas recebem hash BCrypt e as rotas de escrita têm autorização por papel.

O Controller recebe HTTP e delega ao Service. O Service valida regras e coordena transações. Os repositories acessam o banco. DTOs de entrada e saída impedem exposição das entidades JPA e de senhas ou hashes. As dependências usam injeção por construtor.

```text
src/main/java/com/servicehub/
  controller/   Endpoints e documentação
  service/      Regras, transações, paginação e PATCH
  repository/   Interfaces Spring Data JPA
  model/        Entidades e enums
  dto/          Requests, responses e erros
  exception/    Exceções e tratamento global
  config/       OpenAPI e segurança
  security/     JWT, filtro e configuração de acesso
  auth/         Login e resposta do token
  graphql/      Consultas GraphQL
src/main/resources/db/migration/  V1 a V6
src/test/java/com/servicehub/     Integração e migração
docs/                             Diagrama, OpenAPI e evidências
target/                           JAR gerado pelo Maven
```

## Banco e variáveis de ambiente

O perfil padrão `local` usa H2 em arquivo em `data/`, persistindo dados entre reinicializações. Testes usam H2 em memória. Flyway aplica as migrations e Hibernate utiliza `ddl-auto=validate`.

| Variável | Padrão | Finalidade |
|---|---|---|
| PORT | 8080 | Porta HTTP |
| SPRING_PROFILES_ACTIVE | local | Use postgres para PostgreSQL |
| DB_URL | jdbc:postgresql://localhost:5432/servicehub | Conexão PostgreSQL |
| DB_USER | servicehub | Usuário PostgreSQL |
| DB_PASSWORD | servicehub_local | Senha apenas de desenvolvimento |
| DB_NAME | servicehub | Nome do banco no Compose |
| DB_PORT | 5432 | Porta exposta pelo Compose |

Se alterar DB_PORT/DB_NAME no Compose, ajuste DB_URL na aplicação. O arquivo `.env` alimenta o Compose; a aplicação recebe variáveis do terminal/processo.

Com Docker Desktop em execução, copie `.env.example` para `.env`, troque `DB_PASSWORD` e `APP_JWT_SECRET`, e execute:

```powershell
Copy-Item .env.example .env
docker compose up --build -d
docker compose logs -f api
```

Esse comando inicia API e PostgreSQL juntos. Para executar a API fora do Docker contra o PostgreSQL local, use o perfil `postgres` e configure `DB_URL`, `DB_USER` e `DB_PASSWORD` no terminal.

Para voltar ao H2 no mesmo terminal:

```powershell
Remove-Item Env:SPRING_PROFILES_ACTIVE -ErrorAction SilentlyContinue
mvn spring-boot:run
```

V1 a V4 criam as tabelas e restrições do domínio. V5 acrescenta papéis e índices sem apagar dados: usuários que já possuem ofertas recebem PROVIDER, os demais CLIENT. V6 permite o papel administrativo e cria índices compostos. Históricos existentes são preservados. Não edite migrations já aplicadas.

## Endpoints e paginação

Cada coleção possui POST e GET. Cada item `/{id}` possui GET, PUT, PATCH e DELETE:

| Recurso | URI |
|---|---|
| Usuários | /api/v1/users |
| Serviços | /api/v1/services |
| Solicitações | /api/v1/service-requests |
| Avaliações | /api/v1/reviews |

Consultas relacionadas: GET `/api/v1/users/{id}/services`, `/api/v1/users/{id}/service-requests` e `/api/v1/services/{id}/reviews`.

GET de coleção retorna `{content, page, size, totalElements, totalPages}`. `page` começa em zero, `size` tem padrão 20 e máximo 100. Exemplo: `/api/v1/services?page=0&size=5&sort=price,asc`. O resolver do Spring ajusta valores negativos de página e tamanhos fora do limite. Campos de ordenação não permitidos retornam 400.

Filtros: usuários por `email`; serviços por `category`, `minPrice`, `maxPrice`, `active`, `providerId`; pedidos por `status`. Filtros de serviços podem ser combinados. O sub-recurso de serviços do usuário lista somente ofertas ativas. O sub-recurso de pedidos lista os pedidos em que o usuário é cliente.

POST retorna 201 e Location, consultas e atualizações retornam 200, exclusão retorna 204 sem corpo. Erros: 400 dados inválidos, 404 inexistente, 409 conflito, 415 formato não suportado. Também são tratados 405, 406 e falhas inesperadas 500.

## PUT e PATCH

PUT exige todos os campos obrigatórios de entrada e substitui os editáveis. Opcionais omitidos são limpos. PATCH aceita um objeto JSON apenas com os campos a modificar. Campos omitidos permanecem intactos. `null` limpa somente campos opcionais; campos obrigatórios nulos são inválidos. Campos desconhecidos ou gerados pelo servidor são rejeitados. No PATCH de usuário, senha omitida preserva o hash atual. No PUT, senha é obrigatória.

## Regras de negócio

- E-mail normalizado e único; senha de 8 a 60 caracteres e no máximo 72 bytes UTF-8, sem retorno de senha/hash.
- Somente PROVIDER ativo pode possuir uma oferta. Preço maior que zero, com duas casas decimais.
- Novo pedido exige cliente CLIENT ativo, serviço e prestador ativos. O cliente e o prestador devem ser diferentes.
- Novo pedido começa em PENDING. Avanços: PENDING para ACCEPTED, ACCEPTED para IN_PROGRESS, IN_PROGRESS para COMPLETED. CANCELLED é permitido antes da conclusão. Repetir o estado atual é permitido.
- Serviço e cliente do pedido são imutáveis. O preço é registrado na criação e não acompanha mudanças posteriores na oferta.
- Uma avaliação por pedido COMPLETED, nota de 1 a 5 e reviewerId igual ao cliente do pedido. Pedido e avaliador não mudam no PUT/PATCH.
- Relacionamentos impedem exclusões inconsistentes. Não há exclusões automáticas em cascata.
- O papel de usuário com ofertas ou pedidos não pode mudar. CLIENT/PROVIDER são regras de domínio, não autorização de acesso.

## Exemplos cURL

No PowerShell use `curl.exe` no lugar de `curl` caso exista um alias para Invoke-WebRequest. Os exemplos de POST leem arquivos para evitar problemas de escape de JSON no Windows.

```text
curl http://localhost:8080/api/hello
curl -i -X POST http://localhost:8080/api/v1/users -H "Content-Type: application/json" --data-binary @docs/payloads/provider.json
curl -i -X POST http://localhost:8080/api/v1/users -H "Content-Type: application/json" --data-binary @docs/payloads/client.json
curl -i -X POST http://localhost:8080/api/v1/services -H "Content-Type: application/json" --data-binary @docs/payloads/service.json
curl "http://localhost:8080/api/v1/services?category=TECNOLOGIA&minPrice=100&maxPrice=200&page=0&size=5"
curl -i -X PATCH http://localhost:8080/api/v1/services/1 -H "Content-Type: application/json" --data-binary @docs/payloads/service-patch.json
curl -i -X DELETE http://localhost:8080/api/v1/services/1
curl -i http://localhost:8080/api/v1/services/1
```

Substitua IDs pelos retornados na sua execução. Os arquivos de exemplo consideram prestador 1, cliente 2, serviço 1 e pedido 1. O roteiro HTTP em `requests.http` detalha o fluxo completo. DELETE de serviço com pedidos retorna 409: remova primeiro as avaliações e os pedidos criados na demonstração.

## Testes e build

```powershell
mvn test
mvn clean verify
```

Alternativas nesta máquina: `.executar.ps1 -Testar` e `.executar.ps1 -Verificar`. Os testes usam H2 isolado e verificam CRUD, papéis, PATCH, paginação, filtros, transições, avaliações, documentação, JWT e migrações V4 para V6 sem perda de dados. O pacote executável fica em `target/servicehub-api-1.0.0.jar`. O `dist/` antigo pode não refletir as alterações mais recentes; prefira executar `mvn spring-boot:run` ou `docker compose up --build -d`.

## Documentação e apresentação

Abra `docs/diagrama_endpoints_Igor_Raphael_Marques_de_Carvalho.md` ou o PDF correspondente. O Markdown contém Mermaid e detalha os recursos REST originais; a autenticação foi acrescentada nesta continuação. O JSON OpenAPI é extenso porque descreve o contrato completo; schemas são reutilizados por `$ref`.

`docs/roteiro-apresentacao.md` organiza 8 a 10 minutos. `docs/evidencias` contém registros reais das respostas HTTP e instruções para capturas de tela. Os payloads usam pessoas fictícias, sem dados pessoais reais. A identificação acadêmica aparece somente na documentação.

## Limites e cuidados

O projeto é uma implementação acadêmica. Configure um segredo JWT forte e exclusivo antes de expor a API. Leituras e cadastro inicial permanecem públicos para facilitar a demonstração; o cadastro público não pode criar ADMIN. O PostgreSQL está configurado, mas a execução real no Docker/PostgreSQL e os testes Maven precisam ser verificados no computador do aluno antes da entrega. Consulte `docs/verificacao.md` para distinguir as evidências já existentes das validações que ainda precisam ser executadas.

## Continuação das aulas 08 a 12

### Segurança e autenticação (Aulas 08 e 09)

- `POST /api/v1/auth/login` recebe `email` e `password` e devolve um token JWT Bearer com validade configurável.
- A senha é conferida com BCrypt; contas inativas não conseguem entrar.
- O filtro JWT valida assinatura HS256 e expiração. Leitura de ofertas e cadastro inicial são públicos; consultas de usuários, pedidos e avaliações e operações de escrita exigem token e papel compatível.
- O cadastro público aceita `CLIENT` ou `PROVIDER`, mas não permite criar `ADMIN`. Para uso real, o administrador deve ser provisionado por um processo administrativo seguro.
- Configure `APP_JWT_SECRET` com um segredo aleatório de pelo menos 32 bytes. O valor do `.env.example` é apenas para desenvolvimento local.

Exemplo de login:

```http
POST /api/v1/auth/login
Content-Type: application/json

{"email":"cliente@example.com","password":"senha12345"}
```

Use o valor de `accessToken` nas operações protegidas:

```http
Authorization: Bearer SEU_TOKEN
```

### Endpoint GraphQL (Aula 09)

Além da API REST, a aplicação expõe consultas GraphQL em `POST /graphql`:

```json
{"query":"query { services(limit: 100) { id title price category providerId active } }"}
```

Para consultar uma oferta específica: `query { service(id: "1") { id title price active } }`. A implementação é somente de leitura; as operações de escrita continuam na API REST.

### Testes automatizados (Aula 10)

Execute `mvn test`. Os testes existentes verificam regras de negócio, CRUD, validação, paginação e migrações; `JwtServiceTest` também verifica emissão, validação e rejeição de token alterado. Os testes de integração usam o perfil `test` com H2 para não exigir um PostgreSQL ativo.

### Índices e medição (Aula 11)

A migration V6 acrescenta índices compostos. O roteiro de `docs/analise-desempenho-postgresql.md` mostra como usar `EXPLAIN (ANALYZE, BUFFERS)`. Registre medições reais antes de afirmar que uma consulta ficou mais rápida.

### Docker Compose (Aula 12)

1. Copie `.env.example` para `.env` e altere a senha e o segredo JWT.
2. Com Docker Desktop aberto, execute `docker compose up --build -d`.
3. Veja os logs com `docker compose logs -f api` e `docker compose logs -f postgres`.
4. Pare os serviços com `docker compose down`. Os dados permanecem no volume nomeado; para apagá-los deliberadamente, use `docker compose down -v`.

O Compose espera o healthcheck do PostgreSQL antes de iniciar a API. Dentro da rede Compose, a API usa o hostname `postgres`, não `localhost`. O arquivo `.env` contém segredos locais e não deve ser enviado ao Git.

### Ambientes Docker

- Desenvolvimento: `docker compose -f docker-compose.yml -f docker-compose.dev.yml --env-file .env up --build`
- Produção (exemplo de configuração): `docker compose -f docker-compose.yml -f docker-compose.prod.yml --env-file .env up --build -d`

O arquivo de produção exige `DB_PASSWORD` e `APP_JWT_SECRET`; não use valores de exemplo em produção. Configure também HTTPS, gerenciamento de segredos e controles de acesso adequados ao ambiente de implantação.
