# Documentos da entrega

Aluno: Igor Raphael Marques de Carvalho. Matrícula: 2410918.

- diagrama_endpoints_Igor_Raphael_Marques_de_Carvalho.md: contrato das operações REST existentes (inclui login JWT), parâmetros, corpos e respostas, com Mermaid.
- PDF com o mesmo nome: versão para leitura e apresentação.
- openapi.json: contrato completo exportado de /v3/api-docs. Seu tamanho é normal; schemas reutilizados usam $ref.
- roteiro-apresentacao.md: sequência de 9 minutos.
- evidencias/: respostas reais e roteiro preciso de capturas de tela.
- payloads/: JSON para usar com cURL ou Swagger.
- verificacao.md: comandos, resultados e limites de validação.

As descrições da API vêm do código. Para atualizar o JSON, execute a aplicação recompilada e baixe /v3/api-docs. O projeto utiliza paginação com content, page, size, totalElements e totalPages; a versão anterior devolvia arrays simples. O JSON incluído foi atualizado para documentar login JWT; a consulta GraphQL está descrita no README e no schema `src/main/resources/graphql/schema.graphqls`. Para a documentação autoritativa, execute a aplicação atualizada e consulte `/v3/api-docs`.
