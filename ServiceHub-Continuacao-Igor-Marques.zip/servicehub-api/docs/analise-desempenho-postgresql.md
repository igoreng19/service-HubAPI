# Análise de desempenho no PostgreSQL

## Índices adicionados

A migration `V6__Allow_admin_role.sql` acrescenta índices compostos para consultas comuns:

- `idx_services_active_category_price`: filtra ofertas por disponibilidade, categoria e faixa de preço.
- `idx_requests_client_status`: consulta pedidos de um cliente por estado.
- `idx_reviews_reviewer_rating`: filtra avaliações por avaliador e nota.

Os índices não garantem que toda consulta fique mais rápida. Eles ocupam espaço e aumentam o custo de escrita; por isso devem ser validados com consultas reais.

## Como medir

Execute no PostgreSQL, com dados representativos:

```sql
EXPLAIN (ANALYZE, BUFFERS)
SELECT id, title, price
FROM services
WHERE is_active = TRUE
  AND category = 'TECNOLOGIA'
  AND price BETWEEN 50 AND 300
ORDER BY price
LIMIT 20;
```

Compare `Execution Time`, linhas estimadas e reais, leituras de buffers e o tipo de acesso (`Seq Scan`, `Index Scan` ou `Bitmap Index Scan`). Em tabelas pequenas, um `Seq Scan` pode ser a melhor escolha. Registre os resultados antes e depois de criar índices e use `ANALYZE` após carregar dados.

```sql
ANALYZE services;
EXPLAIN (ANALYZE, BUFFERS)
SELECT id, title, price
FROM services
WHERE is_active = TRUE AND category = 'TECNOLOGIA'
ORDER BY price
LIMIT 20;
```

## Limitação

Os resultados dependem do volume e da distribuição dos dados, da versão do PostgreSQL e do ambiente. Não declare ganho de desempenho sem executar e guardar a medição no banco utilizado.

## Comparação REST e GraphQL (Aula 09)

O endpoint REST `GET /api/v1/services` retorna a representação paginada configurada pela API. A consulta GraphQL `POST /graphql` permite solicitar somente os campos necessários. Isso pode reduzir o volume de resposta quando o consumidor precisa de poucos campos, mas não significa automaticamente que GraphQL executa mais rápido: a latência depende de banco, rede, tamanho da resposta e resolver usado.

Para comparar, use a mesma base e os mesmos dados, faça várias chamadas de aquecimento e depois pelo menos 30 medições por endpoint. Registre mediana, tamanho da resposta e código HTTP. Não compare a listagem REST paginada com uma consulta GraphQL sem manter equivalente a quantidade de registros. Os testes de integração verificam a resposta GraphQL, mas a comparação de desempenho real ainda deve ser executada e registrada no ambiente PostgreSQL.


### Script de comparação REST × GraphQL

Com a API iniciada, execute no PowerShell a partir da raiz do projeto:

```powershell
.\scripts\benchmark-rest-graphql.ps1 -Repeticoes 30 -Aquecimento 5
```

O script realiza aquecimento, mede latência e tamanho das respostas, calcula média/mediana e grava as medições em CSV. Para uma comparação rigorosa, mantenha os mesmos dados, faça a execução em ambiente estável e registre data, versão e configuração. REST está paginado e o GraphQL retorna a lista de serviços ativos; se houver mais de 100 serviços, ajuste a comparação para usar a mesma quantidade de registros.

## Tipos de índice estudados na Aula 11

- **B-tree:** padrão para igualdade, intervalos e ordenação; adequado para preço, datas e identificadores.
- **Hash:** adequado para igualdade, sem atender ordenação nem intervalos.
- **GIN:** útil para procurar elementos dentro de arrays, JSONB e documentos de texto.
- **GiST:** estrutura flexível para dados geométricos/espaciais e alguns tipos de busca por proximidade.
- **SP-GiST:** para estruturas particionadas, como tries e algumas distribuições espaciais.
- **BRIN:** compacto para tabelas muito grandes cujos valores seguem a ordem física, como datas de eventos.

A escolha depende da consulta e do tipo de dado. Não crie todos os tipos por padrão: examine consultas reais com `EXPLAIN (ANALYZE, BUFFERS)` e compare custo de leitura, escrita e armazenamento.
