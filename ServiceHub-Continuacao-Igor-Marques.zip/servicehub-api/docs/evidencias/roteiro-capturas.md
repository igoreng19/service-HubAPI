# Capturas de tela para a entrega

Igor Raphael Marques de Carvalho - matrícula 2410918.

Os arquivos JSON desta pasta são registros de requisições HTTP reais, não capturas de tela. O fluxo de evidências criou e removeu apenas seus próprios registros fictícios.

1. **Diagnóstico:** abra http://localhost:8080/api/hello. Capture a URL e o JSON com status OK.
2. **Swagger:** abra /swagger-ui.html, selecione publico e capture título, identificação e grupos de operações.
3. **Criação 201:** expanda POST /api/v1/users, clique Try it out, preencha com docs/payloads/provider.json e Execute. Capture Request URL, código 201, Response body e Location. Anote o ID.
4. **Listagem 200:** GET /api/v1/users, page 0 e size 5. Capture o código 200, content e totalElements.
5. **Exclusão 204:** DELETE /api/v1/users/{id} com o ID criado no passo 3, sem serviços vinculados. Capture 204 e ausência de corpo.
6. **Erro 404:** GET /api/v1/users/{id} usando o mesmo ID excluído. Capture o erro padronizado completo.

Se o e-mail de exemplo já existir, use outro endereço fictício em example.com. Não capture senhas pessoais. Não exclua registros que você não criou para a demonstração. As imagens podem ser nomeadas 01-diagnostico.png a 06-erro-404.png e salvas nesta pasta.
