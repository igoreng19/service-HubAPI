@echo off
setlocal
cd /d "%~dp0"
echo ServiceHub API - requer JDK 21+ e Maven.
echo O projeto sera executado a partir do codigo-fonte atualizado.
echo Swagger: http://localhost:8080/swagger-ui.html
mvn spring-boot:run
if errorlevel 1 (
 echo Falha ao iniciar. Verifique JDK 21, Maven e a porta 8080.
 pause
)
