param(
  [string]$BaseUrl = "http://localhost:8080",
  [int]$Repeticoes = 30,
  [int]$Aquecimento = 5,
  [string]$Csv = "benchmark-rest-graphql.csv"
)
$ErrorActionPreference = "Stop"
$graphqlBody = @{ query = "query { services(limit: 100) { id title price category providerId active } }" } | ConvertTo-Json -Compress
$results = [System.Collections.Generic.List[object]]::new()
foreach ($tipo in @("REST", "GraphQL")) {
  for ($i = 0; $i -lt ($Aquecimento + $Repeticoes); $i++) {
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    if ($tipo -eq "REST") {
      $response = Invoke-WebRequest -Uri "$BaseUrl/api/v1/services?page=0&size=100" -Method Get -UseBasicParsing
    } else {
      $response = Invoke-WebRequest -Uri "$BaseUrl/graphql" -Method Post -ContentType "application/json" -Body $graphqlBody -UseBasicParsing
    }
    $sw.Stop()
    if ($i -ge $Aquecimento) {
      $results.Add([pscustomobject]@{ Tipo=$tipo; Iteracao=($i - $Aquecimento + 1); LatenciaMs=[math]::Round($sw.Elapsed.TotalMilliseconds, 2); Bytes=[Text.Encoding]::UTF8.GetByteCount($response.Content); Status=[int]$response.StatusCode })
    }
  }
}
$results | Export-Csv -NoTypeInformation -Encoding UTF8 $Csv
$results | Group-Object Tipo | ForEach-Object {
  $sorted = @($_.Group | ForEach-Object LatenciaMs | Sort-Object)
  $median = if ($sorted.Count % 2) { $sorted[[int]($sorted.Count / 2)] } else { ($sorted[$sorted.Count/2-1] + $sorted[$sorted.Count/2]) / 2 }
  [pscustomobject]@{ Tipo=$_.Name; Requisicoes=$sorted.Count; MediaMs=[math]::Round((($_.Group | Measure-Object LatenciaMs -Average).Average),2); MedianaMs=[math]::Round($median,2); BytesMedios=[math]::Round((($_.Group | Measure-Object Bytes -Average).Average),0) }
} | Format-Table -AutoSize
Write-Host "Resultados detalhados salvos em $Csv"
