package com.servicehub.auth;

public record LoginResponse(String accessToken, String tokenType, long expiresIn, long userId, String email, String role) {}
