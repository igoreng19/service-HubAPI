package com.servicehub.controller;

import io.swagger.v3.oas.annotations.Hidden;
import java.net.URI;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Hidden
@RestController
public class DocumentationRedirectController {
  @GetMapping("/api-docs")
  public ResponseEntity<Void> legacyDocumentation() {
    return ResponseEntity.status(307).location(URI.create("/v3/api-docs")).build();
  }
}
