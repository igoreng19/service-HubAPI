package com.servicehub.controller;

import com.servicehub.dto.*;
import com.servicehub.service.ReviewService;
import com.servicehub.service.ServiceOfferingService;
import com.servicehub.service.ServiceRequestService;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequiredArgsConstructor
@Tag(name = "Relacionamentos", description = "Consultas paginadas de recursos associados")
@ApiResponse(responseCode = "200", description = "Página de resultados")
@ApiResponse(
    responseCode = "400",
    description = "Parâmetro inválido",
    content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
@ApiResponse(
    responseCode = "404",
    description = "Recurso principal não encontrado",
    content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
public class ProviderServicesController {
  private final ServiceOfferingService services;
  private final ServiceRequestService requests;
  private final ReviewService reviews;

  @GetMapping(value = "/api/v1/users/{id}/services", produces = "application/json")
  @Operation(
      operationId = "listActiveProviderServices",
      summary = "Consultar ofertas ativas do prestador",
      description =
          "Retorna uma página dos serviços ativos associados ao usuário. Usuário inexistente"
              + " retorna 404.")
  @PreAuthorize("hasRole('ADMIN')")
  public PageResponse<ServiceOfferingResponse> services(
      @Parameter(description = "ID do usuário", example = "1") @PathVariable Long id,
      @ParameterObject @PageableDefault(sort = "id") Pageable pageable) {
    return services.providerServices(id, pageable);
  }

  @GetMapping(value = "/api/v1/users/{id}/service-requests", produces = "application/json")
  @Operation(
      operationId = "listClientRequests",
      summary = "Consultar pedidos do cliente",
      description =
          "Retorna uma página das solicitações nas quais o usuário informado é o cliente"
              + " contratante.")
  @PreAuthorize("hasRole('ADMIN')")
  public PageResponse<ServiceRequestResponse> requests(
      @Parameter(description = "ID do usuário cliente", example = "2") @PathVariable Long id,
      @ParameterObject @PageableDefault(sort = "id") Pageable pageable) {
    return requests.byClient(id, pageable);
  }

  @GetMapping(value = "/api/v1/services/{id}/reviews", produces = "application/json")
  @Operation(
      operationId = "listServiceReviews",
      summary = "Consultar avaliações do serviço",
      description =
          "Retorna uma página das avaliações de pedidos concluídos vinculados à oferta informada.")
  @PreAuthorize("hasRole('ADMIN')")
  public PageResponse<ReviewResponse> reviews(
      @Parameter(description = "ID da oferta", example = "1") @PathVariable Long id,
      @ParameterObject @PageableDefault(sort = "id") Pageable pageable) {
    return reviews.byService(id, pageable);
  }
}
