package com.servicehub.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.servicehub.model.*;
import com.servicehub.dto.*;
import com.servicehub.service.ReviewService;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping(value = "/api/v1/reviews", produces = "application/json")
@Tag(name = "Avaliações", description = "Operações de avaliações da plataforma ServiceHub")
@RequiredArgsConstructor
public class ReviewController {
  private final ReviewService service;

  @PostMapping(value = "", consumes = "application/json")
  @Operation(
      operationId = "createReview",
      summary = "Cadastrar avaliações",
      description =
          "Registra nota e comentário para um pedido concluído, indicando como avaliador o cliente"
              + " do pedido.")
  @ApiResponses({
    @ApiResponse(
        responseCode = "201",
        description = "avaliação criada.",
        headers =
            @io.swagger.v3.oas.annotations.headers.Header(
                name = "Location",
                description = "URI do recurso criado",
                schema = @Schema(type = "string"))),
    @ApiResponse(
        responseCode = "400",
        description = "entrada inválida.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "pedido ou avaliador ausente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "regra de avaliação violada.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasRole('CLIENT')")
  public ResponseEntity<ReviewResponse> create(@Valid @RequestBody ReviewInput dto) {
    var created = service.create(dto);
    return ResponseEntity.created(java.net.URI.create("/api/v1/reviews/" + created.id()))
        .body(created);
  }

  @GetMapping("")
  @Operation(
      operationId = "listReview",
      summary = "Listar avaliações com paginação",
      description =
          "Retorna uma página de avaliações. page começa em 0, size tem máximo de 100 e sort aceita"
              + " campo,direção. Os filtros informados são combinados.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Página de avaliações."),
    @ApiResponse(
        responseCode = "400",
        description = "Parâmetros inválidos.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','ADMIN')")
  public ResponseEntity<PageResponse<ReviewResponse>> list(
      @ParameterObject @PageableDefault(sort = "id", size = 20) Pageable pageable) {
    return ResponseEntity.ok(service.list(pageable));
  }

  @GetMapping("/{id}")
  @Operation(
      operationId = "getReview",
      summary = "Consultar avaliações por ID",
      description = "Consulta os detalhes de uma avaliação específica pelo ID.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "avaliação."),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "avaliação inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','ADMIN')")
  public ResponseEntity<ReviewResponse> get(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id) {
    return ResponseEntity.ok(service.findById(id));
  }

  @PutMapping(value = "/{id}", consumes = "application/json")
  @Operation(
      operationId = "updateReview",
      summary = "Substituir avaliações",
      description =
          "Substitui nota e comentário, mantendo o pedido e o avaliador originais. O pedido deve"
              + " continuar concluído.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "avaliação atualizada."),
    @ApiResponse(
        responseCode = "400",
        description = "entrada inválida.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "avaliação ou referência ausente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "vínculos ou regra inválidos.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','ADMIN')")
  public ResponseEntity<ReviewResponse> update(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id,
      @Valid @RequestBody ReviewInput dto) {
    return ResponseEntity.ok(service.update(id, dto));
  }

  @DeleteMapping("/{id}")
  @Operation(
      operationId = "deleteReview",
      summary = "Excluir avaliações",
      description =
          "Exclui somente a avaliação. O pedido, o serviço e o usuário permanecem cadastrados.")
  @ApiResponses({
    @ApiResponse(responseCode = "204", description = "excluída.", content = @Content),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "avaliação inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','ADMIN')")
  public ResponseEntity<Void> delete(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id) {
    service.delete(id);
    return ResponseEntity.noContent().build();
  }

  @PatchMapping(value = "/{id}", consumes = "application/json")
  @Operation(
      operationId = "patchReview",
      summary = "Atualizar parcialmente avaliações",
      description =
          "Altera nota e comentário da avaliação. Pedido e avaliador não podem mudar. Campos"
              + " opcionais podem ser limpos com null. Campos obrigatórios não aceitam null. Campos"
              + " desconhecidos são rejeitados.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Recurso atualizado"),
    @ApiResponse(
        responseCode = "400",
        description = "Dados inválidos",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "Recurso ou referência inexistente",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "Conflito de negócio",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('CLIENT','ADMIN')")
  public ResponseEntity<ReviewResponse> patch(
      @Parameter(description = "ID do recurso", example = "1") @PathVariable Long id,
      @io.swagger.v3.oas.annotations.parameters.RequestBody(
              required = true,
              description = "Campos a alterar",
              content = @Content(schema = @Schema(implementation = ReviewPatchInput.class)))
          @RequestBody
          JsonNode patch) {
    return ResponseEntity.ok(service.patch(id, patch));
  }
}
