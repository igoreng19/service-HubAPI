package com.servicehub.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.servicehub.model.*;
import com.servicehub.dto.*;
import com.servicehub.service.ServiceOfferingService;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.math.BigDecimal;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping(value = "/api/v1/services", produces = "application/json")
@Tag(name = "Serviços", description = "Operações de serviços da plataforma ServiceHub")
@RequiredArgsConstructor
public class ServiceOfferingController {
  private final ServiceOfferingService service;

  @PostMapping(value = "", consumes = "application/json")
  @Operation(
      operationId = "createServiceOffering",
      summary = "Cadastrar serviços",
      description = "Publica uma oferta de serviço vinculada a um prestador existente e ativo.")
  @ApiResponses({
    @ApiResponse(
        responseCode = "201",
        description = "serviço criado.",
        headers =
            @io.swagger.v3.oas.annotations.headers.Header(
                name = "Location",
                description = "URI do recurso criado",
                schema = @Schema(type = "string"))),
    @ApiResponse(
        responseCode = "400",
        description = "entrada inválida.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "prestador inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "prestador inativo.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('PROVIDER','ADMIN')")
  public ResponseEntity<ServiceOfferingResponse> create(
      @Valid @RequestBody ServiceOfferingInput dto) {
    var created = service.create(dto);
    return ResponseEntity.created(java.net.URI.create("/api/v1/services/" + created.id()))
        .body(created);
  }

  @GetMapping("")
  @Operation(
      operationId = "listServiceOffering",
      summary = "Listar serviços com paginação",
      description =
          "Retorna uma página de serviços. page começa em 0, size tem máximo de 100 e sort aceita"
              + " campo,direção. Os filtros informados são combinados.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Página de serviços."),
    @ApiResponse(
        responseCode = "400",
        description = "Parâmetros inválidos.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  public ResponseEntity<PageResponse<ServiceOfferingResponse>> list(
      @Parameter(description = "Categoria do serviço") @RequestParam(required = false)
          ServiceCategory category,
      @Parameter(description = "Preço mínimo inclusivo") @RequestParam(required = false)
          BigDecimal minPrice,
      @Parameter(description = "Preço máximo inclusivo") @RequestParam(required = false)
          BigDecimal maxPrice,
      @Parameter(description = "Filtrar disponibilidade") @RequestParam(required = false)
          Boolean active,
      @Parameter(description = "ID do prestador") @RequestParam(required = false) Long providerId,
      @ParameterObject @PageableDefault(sort = "id", size = 20) Pageable pageable) {
    return ResponseEntity.ok(
        service.list(category, minPrice, maxPrice, active, providerId, pageable));
  }

  @GetMapping("/{id}")
  @Operation(
      operationId = "getServiceOffering",
      summary = "Consultar serviços por ID",
      description = "Consulta título, preço, categoria e ID do prestador de uma oferta.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "serviço."),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "serviço inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  public ResponseEntity<ServiceOfferingResponse> get(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id) {
    return ResponseEntity.ok(service.findById(id));
  }

  @PutMapping(value = "/{id}", consumes = "application/json")
  @Operation(
      operationId = "updateServiceOffering",
      summary = "Substituir serviços",
      description =
          "Substitui título, descrição, preço, categoria, prestador e disponibilidade da oferta.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "serviço atualizado."),
    @ApiResponse(
        responseCode = "400",
        description = "entrada inválida.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "serviço ou prestador ausente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "prestador inativo.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('PROVIDER','ADMIN')")
  public ResponseEntity<ServiceOfferingResponse> update(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id,
      @Valid @RequestBody ServiceOfferingInput dto) {
    return ResponseEntity.ok(service.update(id, dto));
  }

  @DeleteMapping("/{id}")
  @Operation(
      operationId = "deleteServiceOffering",
      summary = "Excluir serviços",
      description = "Remove a oferta somente se nenhum pedido estiver associado a ela.")
  @ApiResponses({
    @ApiResponse(responseCode = "204", description = "excluído.", content = @Content),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "serviço inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "serviço possui pedidos.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('PROVIDER','ADMIN')")
  public ResponseEntity<Void> delete(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id) {
    service.delete(id);
    return ResponseEntity.noContent().build();
  }

  @PatchMapping(value = "/{id}", consumes = "application/json")
  @Operation(
      operationId = "patchServiceOffering",
      summary = "Atualizar parcialmente serviços",
      description =
          "Altera somente os campos enviados da oferta, validando preço e prestador PROVIDER ativo."
              + " Campos opcionais podem ser limpos com null. Campos obrigatórios não aceitam null."
              + " Campos desconhecidos são rejeitados.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Recurso atualizado"),
    @ApiResponse(
        responseCode = "400",
        description = "Dados inválidos",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "Recurso ou referência inexistente",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "Conflito de negócio",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasAnyRole('PROVIDER','ADMIN')")
  public ResponseEntity<ServiceOfferingResponse> patch(
      @Parameter(description = "ID do recurso", example = "1") @PathVariable Long id,
      @io.swagger.v3.oas.annotations.parameters.RequestBody(
              required = true,
              description = "Campos a alterar",
              content =
                  @Content(schema = @Schema(implementation = ServiceOfferingPatchInput.class)))
          @RequestBody
          JsonNode patch) {
    return ResponseEntity.ok(service.patch(id, patch));
  }
}
