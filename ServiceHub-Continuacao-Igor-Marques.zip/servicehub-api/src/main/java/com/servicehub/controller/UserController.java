package com.servicehub.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.servicehub.model.*;
import com.servicehub.dto.*;
import com.servicehub.service.UserService;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping(value = "/api/v1/users", produces = "application/json")
@Tag(name = "Usuários", description = "Operações de usuários da plataforma ServiceHub")
@RequiredArgsConstructor
public class UserController {
  private final UserService service;

  @PostMapping(value = "", consumes = "application/json")
  @Operation(
      operationId = "createUser",
      summary = "Cadastrar usuários",
      description =
          "Cadastra uma pessoa como possível cliente ou prestador. Normaliza o e-mail e armazena a"
              + " senha com hash BCrypt.")
  @ApiResponses({
    @ApiResponse(
        responseCode = "201",
        description = "usuário criado.",
        headers =
            @io.swagger.v3.oas.annotations.headers.Header(
                name = "Location",
                description = "URI do recurso criado",
                schema = @Schema(type = "string"))),
    @ApiResponse(
        responseCode = "400",
        description = "entrada inválida.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "e-mail já cadastrado.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  public ResponseEntity<UserResponse> create(@Valid @RequestBody UserInput dto) {
    var created = service.create(dto);
    return ResponseEntity.created(java.net.URI.create("/api/v1/users/" + created.id()))
        .body(created);
  }

  @GetMapping("")
  @Operation(
      operationId = "listUser",
      summary = "Listar usuários com paginação",
      description =
          "Retorna uma página de usuários. page começa em 0, size tem máximo de 100 e sort aceita"
              + " campo,direção. Os filtros informados são combinados.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Página de usuários."),
    @ApiResponse(
        responseCode = "400",
        description = "Parâmetros inválidos.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<PageResponse<UserResponse>> list(
      @Parameter(description = "E-mail exato, sem diferença entre maiúsculas e minúsculas")
          @RequestParam(required = false)
          String email,
      @ParameterObject @PageableDefault(sort = "id", size = 20) Pageable pageable) {
    return ResponseEntity.ok(service.list(email, pageable));
  }

  @GetMapping("/{id}")
  @Operation(
      operationId = "getUser",
      summary = "Consultar usuários por ID",
      description = "Consulta os dados de uma pessoa cadastrada pelo ID.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "usuário."),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "usuário inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<UserResponse> get(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id) {
    return ResponseEntity.ok(service.findById(id));
  }

  @PutMapping(value = "/{id}", consumes = "application/json")
  @Operation(
      operationId = "updateUser",
      summary = "Substituir usuários",
      description =
          "Substitui nome, e-mail, senha, telefone, biografia, foto e situação do usuário.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "usuário atualizado."),
    @ApiResponse(
        responseCode = "400",
        description = "entrada inválida.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "usuário inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "e-mail de outro usuário.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<UserResponse> update(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id,
      @Valid @RequestBody UserInput dto) {
    return ResponseEntity.ok(service.update(id, dto));
  }

  @DeleteMapping("/{id}")
  @Operation(
      operationId = "deleteUser",
      summary = "Excluir usuários",
      description =
          "Remove o usuário apenas se ele não possuir serviços, pedidos como cliente ou avaliações"
              + " vinculadas.")
  @ApiResponses({
    @ApiResponse(responseCode = "204", description = "excluído.", content = @Content),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "usuário inexistente.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "existem vínculos.",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<Void> delete(
      @Parameter(description = "Identificador do recurso", example = "1", required = true)
          @PathVariable
          Long id) {
    service.delete(id);
    return ResponseEntity.noContent().build();
  }

  @PatchMapping(value = "/{id}", consumes = "application/json")
  @Operation(
      operationId = "patchUser",
      summary = "Atualizar parcialmente usuários",
      description =
          "Altera somente os campos enviados do usuário. Senha omitida permanece inalterada. Não"
              + " permite mudar papel se houver serviços ou pedidos associados. Campos opcionais"
              + " podem ser limpos com null. Campos obrigatórios não aceitam null. Campos"
              + " desconhecidos são rejeitados.")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Recurso atualizado"),
    @ApiResponse(
        responseCode = "400",
        description = "Dados inválidos",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "404",
        description = "Recurso ou referência inexistente",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
    @ApiResponse(
        responseCode = "409",
        description = "Conflito de negócio",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  })
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<UserResponse> patch(
      @Parameter(description = "ID do recurso", example = "1") @PathVariable Long id,
      @io.swagger.v3.oas.annotations.parameters.RequestBody(
              required = true,
              description = "Campos a alterar",
              content = @Content(schema = @Schema(implementation = UserPatchInput.class)))
          @RequestBody
          JsonNode patch) {
    return ResponseEntity.ok(service.patch(id, patch));
  }
}
