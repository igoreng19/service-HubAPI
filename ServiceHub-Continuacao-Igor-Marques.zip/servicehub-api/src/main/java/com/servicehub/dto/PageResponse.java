package com.servicehub.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.springframework.data.domain.Page;

@Schema(description = "Página de resultados; page começa em zero e size tem limite de 100")
public record PageResponse<T>(
    @Schema(description = "Registros desta página") List<T> content,
    @Schema(description = "Página atual", example = "0") int page,
    @Schema(description = "Tamanho solicitado", example = "20") int size,
    @Schema(description = "Quantidade total de registros", example = "1") long totalElements,
    @Schema(description = "Quantidade total de páginas", example = "1") int totalPages) {
  public static <T> PageResponse<T> from(Page<T> page) {
    return new PageResponse<>(
        page.getContent(),
        page.getNumber(),
        page.getSize(),
        page.getTotalElements(),
        page.getTotalPages());
  }
}
