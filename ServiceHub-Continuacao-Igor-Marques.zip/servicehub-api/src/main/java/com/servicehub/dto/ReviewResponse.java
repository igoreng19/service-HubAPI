package com.servicehub.dto;

import com.servicehub.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDateTime;

@Schema(description = "Representação de Review, sem senha ou hash.")
public record ReviewResponse(
    @Schema(description = "Identificador", example = "1") Long id,
    @Schema(description = "Pedido concluído avaliado", example = "1") Long requestId,
    @Schema(description = "ID do cliente do pedido", example = "2") Long reviewerId,
    @Schema(description = "Nota de 1 a 5", example = "5") Integer rating,
    @Schema(description = "Comentário", example = "Ótimo atendimento") String comment,
    @Schema(description = "Data de criação", example = "2026-09-14T10:00:00")
        LocalDateTime createdAt,
    @Schema(description = "Data da última alteração", example = "2026-09-14T10:00:00")
        LocalDateTime updatedAt) {
  public static ReviewResponse from(Review e) {
    return new ReviewResponse(
        e.getId(),
        e.getRequest().getId(),
        e.getReviewer().getId(),
        e.getRating(),
        e.getComment(),
        e.getCreatedAt(),
        e.getUpdatedAt());
  }
}
