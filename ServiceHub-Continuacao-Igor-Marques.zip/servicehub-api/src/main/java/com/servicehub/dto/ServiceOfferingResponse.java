package com.servicehub.dto;

import com.servicehub.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Schema(description = "Representação de ServiceOffering, sem senha ou hash.")
public record ServiceOfferingResponse(
    @Schema(description = "Identificador", example = "1") Long id,
    @Schema(description = "Título do serviço", example = "Manutenção de computador") String title,
    @Schema(description = "Descrição do serviço", example = "Limpeza e diagnóstico")
        String description,
    @Schema(description = "Preço em reais", example = "150.00") BigDecimal price,
    @Schema(description = "Categoria", example = "TECNOLOGIA") ServiceCategory category,
    @Schema(description = "ID de usuário prestador", example = "1") Long providerId,
    @Schema(description = "Serviço disponível", example = "true") Boolean active,
    @Schema(description = "Data de criação", example = "2026-09-14T10:00:00")
        LocalDateTime createdAt,
    @Schema(description = "Data da última alteração", example = "2026-09-14T10:00:00")
        LocalDateTime updatedAt) {
  public static ServiceOfferingResponse from(ServiceOffering e) {
    return new ServiceOfferingResponse(
        e.getId(),
        e.getTitle(),
        e.getDescription(),
        e.getPrice(),
        e.getCategory(),
        e.getProvider().getId(),
        e.isActive(),
        e.getCreatedAt(),
        e.getUpdatedAt());
  }
}
