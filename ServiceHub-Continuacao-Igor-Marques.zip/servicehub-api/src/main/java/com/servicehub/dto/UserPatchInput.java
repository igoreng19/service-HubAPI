package com.servicehub.dto;

import com.servicehub.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;

@Schema(
    description =
        "Dados para criar ou substituir User. PATCH altera somente campos enviados; null limpa"
            + " campos opcionais.")
public record UserPatchInput(
    @Schema(description = "Nome completo", example = "Maria Silva") @Size(max = 100)
        String fullName,
    @Schema(description = "E-mail único", example = "maria@example.com") @Email @Size(max = 255)
        String email,
    @Schema(
            description = "Senha de 8 a 60 caracteres; somente entrada",
            accessMode = Schema.AccessMode.WRITE_ONLY,
            example = "senha12345")
        @Size(min = 8, max = 60)
        String password,
    @Schema(description = "Telefone opcional", example = "11999999999") @Size(max = 20)
        String phone,
    @Schema(description = "Apresentação do usuário", example = "Técnica em informática")
        @Size(max = 5000)
        String bio,
    @Schema(description = "URL opcional da foto", example = "https://example.com/avatar.png")
        @Size(max = 500)
        String avatarUrl,
    @Schema(description = "Cadastro ativo", example = "true") Boolean active,
    @Schema(description = "Papel do usuário", example = "PROVIDER") UserRole role) {}
