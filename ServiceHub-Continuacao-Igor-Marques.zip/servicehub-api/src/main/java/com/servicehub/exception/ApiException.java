package com.servicehub.exception;

import org.springframework.http.HttpStatus;

public class ApiException extends RuntimeException {
  private final HttpStatus status;

  public ApiException(HttpStatus status, String message) {
    super(message);
    this.status = status;
  }

  public HttpStatus getStatus() {
    return status;
  }

  public static ApiException notFound(String name, Long id) {
    return new ResourceNotFoundException(name, id);
  }

  public static ApiException conflict(String message) {
    return new BusinessRuleException(message);
  }
}
