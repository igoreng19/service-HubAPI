package com.servicehub.exception;

import com.servicehub.dto.ErrorResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import java.time.Instant;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
  private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);

  private ResponseEntity<ErrorResponse> error(
      HttpStatus s, String m, HttpServletRequest r, Map<String, String> fields) {
    return ResponseEntity.status(s)
        .contentType(MediaType.APPLICATION_JSON)
        .body(
            new ErrorResponse(
                Instant.now(), s.value(), s.getReasonPhrase(), m, r.getRequestURI(), fields));
  }

  @ExceptionHandler(ApiException.class)
  public ResponseEntity<ErrorResponse> business(ApiException e, HttpServletRequest r) {
    return error(e.getStatus(), e.getMessage(), r, Map.of());
  }

  @ExceptionHandler(MethodArgumentNotValidException.class)
  public ResponseEntity<ErrorResponse> validation(
      MethodArgumentNotValidException e, HttpServletRequest r) {
    Map<String, String> fields = new TreeMap<>();
    e.getBindingResult()
        .getFieldErrors()
        .forEach(f -> fields.put(f.getField(), f.getDefaultMessage()));
    return error(HttpStatus.BAD_REQUEST, "Dados inválidos", r, fields);
  }

  @ExceptionHandler(ConstraintViolationException.class)
  public ResponseEntity<ErrorResponse> validation(
      ConstraintViolationException e, HttpServletRequest r) {
    Map<String, String> fields = new TreeMap<>();
    e.getConstraintViolations()
        .forEach(v -> fields.put(v.getPropertyPath().toString(), v.getMessage()));
    return error(HttpStatus.BAD_REQUEST, "Dados inválidos", r, fields);
  }

  @ExceptionHandler({
    HttpMessageNotReadableException.class,
    MethodArgumentTypeMismatchException.class,
    IllegalArgumentException.class
  })
  public ResponseEntity<ErrorResponse> malformed(Exception e, HttpServletRequest r) {
    return error(
        HttpStatus.BAD_REQUEST,
        "JSON, tipo ou parâmetro inválido. Consulte o schema no Swagger.",
        r,
        Map.of());
  }

  @ExceptionHandler(DataIntegrityViolationException.class)
  public ResponseEntity<ErrorResponse> integrity(Exception e, HttpServletRequest r) {
    return error(
        HttpStatus.CONFLICT, "Operação viola unicidade ou relacionamento existente.", r, Map.of());
  }

  @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
  public ResponseEntity<ErrorResponse> media(Exception e, HttpServletRequest r) {
    return error(
        HttpStatus.UNSUPPORTED_MEDIA_TYPE, "Envie o corpo em application/json.", r, Map.of());
  }

  @ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
  public ResponseEntity<ErrorResponse> accept(Exception e, HttpServletRequest r) {
    return error(
        HttpStatus.NOT_ACCEPTABLE, "A representação disponível é application/json.", r, Map.of());
  }

  @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
  public ResponseEntity<ErrorResponse> method(
      HttpRequestMethodNotSupportedException e, HttpServletRequest r) {
    var response =
        error(HttpStatus.METHOD_NOT_ALLOWED, "Método não permitido nesta URI.", r, Map.of());
    HttpHeaders headers = new HttpHeaders();
    headers.putAll(response.getHeaders());
    if (e.getSupportedHttpMethods() != null) headers.setAllow(e.getSupportedHttpMethods());
    return new ResponseEntity<>(response.getBody(), headers, response.getStatusCode());
  }

  @ExceptionHandler(NoResourceFoundException.class)
  public ResponseEntity<ErrorResponse> missing(Exception e, HttpServletRequest r) {
    return error(HttpStatus.NOT_FOUND, "Endpoint não encontrado.", r, Map.of());
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<ErrorResponse> unexpected(Exception e, HttpServletRequest r) {
    LOG.error("Falha inesperada em {}", r.getRequestURI(), e);
    return error(HttpStatus.INTERNAL_SERVER_ERROR, "Falha inesperada no servidor.", r, Map.of());
  }
}
