package com.servicehub.model;

public enum ServiceCategory {
  TECNOLOGIA,
  LIMPEZA,
  MANUTENCAO,
  EDUCACAO,
  BELEZA,
  OUTROS
}
