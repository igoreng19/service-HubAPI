package com.servicehub.repository;

import com.servicehub.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository
    extends JpaRepository<Review, Long>,
        org.springframework.data.jpa.repository.JpaSpecificationExecutor<Review> {
  boolean existsByRequestId(Long requestId);

  boolean existsByRequestIdAndIdNot(Long requestId, Long id);

  boolean existsByReviewerId(Long reviewerId);

  org.springframework.data.domain.Page<Review> findByRequestServiceId(
      Long serviceId, org.springframework.data.domain.Pageable pageable);
}
