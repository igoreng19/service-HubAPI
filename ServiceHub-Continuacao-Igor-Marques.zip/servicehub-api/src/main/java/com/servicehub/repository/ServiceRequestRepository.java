package com.servicehub.repository;

import com.servicehub.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceRequestRepository
    extends JpaRepository<ServiceRequest, Long>,
        org.springframework.data.jpa.repository.JpaSpecificationExecutor<ServiceRequest> {
  boolean existsByServiceId(Long serviceId);

  boolean existsByClientId(Long clientId);

  org.springframework.data.domain.Page<ServiceRequest> findByClientId(
      Long clientId, org.springframework.data.domain.Pageable pageable);
}
