package com.servicehub.repository;

import com.servicehub.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository
    extends JpaRepository<User, Long>,
        org.springframework.data.jpa.repository.JpaSpecificationExecutor<User> {
  boolean existsByEmailIgnoreCase(String email);

  boolean existsByEmailIgnoreCaseAndIdNot(String email, Long id);

  java.util.List<User> findByFullNameContainingIgnoreCase(String name);

  java.util.Optional<User> findByEmailIgnoreCase(String email);
}
