package com.servicehub.service;

import com.servicehub.exception.ApiException;
import java.util.Set;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;

final class PaginationSupport {
  private PaginationSupport() {}

  static Pageable check(Pageable p, String... fields) {
    Set<String> allowed = Set.of(fields);
    for (var order : p.getSort())
      if (!allowed.contains(order.getProperty()))
        throw new ApiException(
            HttpStatus.BAD_REQUEST, "Campo de ordenação inválido: " + order.getProperty());
    return p;
  }
}
