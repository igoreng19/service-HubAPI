package com.servicehub.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.servicehub.exception.ApiException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validator;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PatchSupport {
  private final ObjectMapper mapper;
  private final Validator validator;

  public <T> T merge(T current, JsonNode patch, Class<T> type, Set<String> skipValidation) {
    if (patch == null || !patch.isObject())
      throw new ApiException(HttpStatus.BAD_REQUEST, "PATCH exige um objeto JSON.");
    ObjectNode merged = mapper.valueToTree(current);
    patch
        .fields()
        .forEachRemaining(
            entry -> {
              if (!merged.has(entry.getKey()))
                throw new ApiException(
                    HttpStatus.BAD_REQUEST,
                    "Campo desconhecido ou não editável: " + entry.getKey());
              merged.set(entry.getKey(), entry.getValue());
            });
    T value;
    try {
      value = mapper.treeToValue(merged, type);
    } catch (Exception e) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "Tipo inválido no PATCH.");
    }
    Set<ConstraintViolation<T>> violations = new HashSet<>(validator.validate(value));
    violations.removeIf(
        v ->
            skipValidation.contains(v.getPropertyPath().toString())
                && !patch.has(v.getPropertyPath().toString()));
    if (!violations.isEmpty()) throw new ConstraintViolationException(violations);
    return value;
  }
}
