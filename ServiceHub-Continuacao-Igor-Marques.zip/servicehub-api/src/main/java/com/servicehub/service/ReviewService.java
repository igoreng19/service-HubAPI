package com.servicehub.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.servicehub.exception.ApiException;
import com.servicehub.model.*;
import com.servicehub.dto.*;
import com.servicehub.repository.*;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class ReviewService {
  private final UserRepository users;
  private final ServiceOfferingRepository offerings;
  private final ServiceRequestRepository requests;
  private final ReviewRepository reviews;
  private final PatchSupport patches;

  private Review entity(Long id) {
    return reviews.findById(id).orElseThrow(() -> ApiException.notFound("Review", id));
  }

  @Transactional(readOnly = true)
  public List<ReviewResponse> findAll() {
    return reviews.findAll(org.springframework.data.domain.Sort.by("id")).stream()
        .map(ReviewResponse::from)
        .toList();
  }

  @Transactional(readOnly = true)
  public ReviewResponse findById(Long id) {
    return ReviewResponse.from(entity(id));
  }

  public ReviewResponse create(ReviewInput dto) {
    Review e = new Review();
    apply(e, dto);
    return ReviewResponse.from(reviews.saveAndFlush(e));
  }

  public ReviewResponse update(Long id, ReviewInput dto) {
    Review e = entity(id);
    apply(e, dto);
    return ReviewResponse.from(reviews.saveAndFlush(e));
  }

  public void delete(Long id) {
    Review e = entity(id);
    reviews.delete(e);
    reviews.flush();
  }

  private void apply(Review e, ReviewInput dto) {
    ServiceRequest request =
        requests
            .findById(dto.requestId())
            .orElseThrow(() -> ApiException.notFound("Pedido", dto.requestId()));
    User reviewer =
        users
            .findById(dto.reviewerId())
            .orElseThrow(() -> ApiException.notFound("Avaliador", dto.reviewerId()));
    if (request.getStatus() != RequestStatus.COMPLETED)
      throw ApiException.conflict("Só é possível avaliar pedidos concluídos.");
    if (!request.getClient().getId().equals(reviewer.getId()))
      throw ApiException.conflict("A avaliação deve indicar o cliente do pedido.");
    if (e.getId() != null
        && (!e.getRequest().getId().equals(dto.requestId())
            || !e.getReviewer().getId().equals(dto.reviewerId())))
      throw ApiException.conflict("Pedido e avaliador são imutáveis.");
    if (e.getId() == null
        ? reviews.existsByRequestId(dto.requestId())
        : reviews.existsByRequestIdAndIdNot(dto.requestId(), e.getId()))
      throw ApiException.conflict("Pedido já avaliado.");
    e.setRating(dto.rating());
    e.setComment(TextSanitizer.plainText(dto.comment()));
    e.setRequest(request);
    e.setReviewer(reviewer);
  }

  @Transactional(readOnly = true)
  public PageResponse<ReviewResponse> list(Pageable pageable) {
    return PageResponse.from(
        reviews
            .findAll(PaginationSupport.check(pageable, "id", "rating", "createdAt"))
            .map(ReviewResponse::from));
  }

  @Transactional(readOnly = true)
  public PageResponse<ReviewResponse> byService(Long id, Pageable pageable) {
    if (!offerings.existsById(id)) throw ApiException.notFound("Serviço", id);
    return PageResponse.from(
        reviews
            .findByRequestServiceId(
                id, PaginationSupport.check(pageable, "id", "rating", "createdAt"))
            .map(ReviewResponse::from));
  }

  public ReviewResponse patch(Long id, JsonNode patch) {
    Review e = entity(id);
    ReviewInput current =
        new ReviewInput(
            e.getRequest().getId(), e.getReviewer().getId(), e.getRating(), e.getComment());
    apply(e, patches.merge(current, patch, ReviewInput.class, Set.of()));
    return ReviewResponse.from(reviews.saveAndFlush(e));
  }
}
