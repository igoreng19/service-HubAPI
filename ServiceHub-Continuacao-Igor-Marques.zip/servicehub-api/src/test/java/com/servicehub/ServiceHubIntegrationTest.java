package com.servicehub;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

@SpringBootTest(
    properties = {
      "spring.profiles.active=test",
      "spring.datasource.url=jdbc:h2:mem:testhub;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1",
      "spring.datasource.username=sa",
      "spring.datasource.password="
    })
@org.springframework.transaction.annotation.Transactional
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class ServiceHubIntegrationTest {
  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired com.servicehub.repository.UserRepository users;

  @Test
  void partialUpdatesRolesAndFilters() throws Exception {
    long provider =
        call(post("/api/v1/users"), provider("provider.patch@example.com"), 201).get("id").asLong();
    long client =
        call(post("/api/v1/users"), user("client.patch@example.com"), 201).get("id").asLong();
    String originalHash = users.findById(client).orElseThrow().getPasswordHash();
    call(patch("/api/v1/users/" + client), Map.of("phone", "11911111111"), 200);
    assertThat(users.findById(client).orElseThrow().getPasswordHash()).isEqualTo(originalHash);
    call(patch("/api/v1/users/" + client), Map.of("password", "novaSenha123"), 200);
    assertThat(users.findById(client).orElseThrow().getPasswordHash()).isNotEqualTo(originalHash);
    mvc.perform(
            patch("/api/v1/users/" + client)
                .contentType("application/json")
                .content("{\"phone\":null}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.phone").doesNotExist());
    mvc.perform(
            patch("/api/v1/users/" + client)
                .contentType("application/json")
                .content("{\"password\":null}"))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.fieldErrors.password").exists());
    call(patch("/api/v1/users/" + client), Map.of("role", "ADMIN"), 400);
    call(patch("/api/v1/users/" + client), Map.of("passwordHash", "bad"), 400);
    call(patch("/api/v1/users/" + client), Map.of("email", "provider.patch@example.com"), 409);
    call(post("/api/v1/services"), offering(client), 409);
    long service = call(post("/api/v1/services"), offering(provider), 201).get("id").asLong();
    call(patch("/api/v1/users/" + provider), Map.of("role", "CLIENT"), 409);
    call(patch("/api/v1/services/" + service), Map.of("price", 200), 200);
    call(patch("/api/v1/services/" + service), Map.of("price", -1), 400);
    assertThat(
            call(
                    get("/api/v1/services?category=TECNOLOGIA&minPrice=199&maxPrice=201&size=1"),
                    null,
                    200)
                .get("totalElements")
                .asLong())
        .isEqualTo(1);
    assertThat(call(get("/api/v1/services?minPrice=250"), null, 200).get("content").size())
        .isZero();
    call(get("/api/v1/services?minPrice=250&maxPrice=1"), null, 400);
    call(get("/api/v1/services?sort=passwordHash,asc"), null, 400);
    assertThat(
            call(get("/api/v1/users?email=CLIENT.PATCH@example.com"), null, 200)
                .get("totalElements")
                .asLong())
        .isEqualTo(1);
    call(patch("/api/v1/services/" + service), Map.of("active", false), 200);
    call(post("/api/v1/service-requests"), order(service, client, "PENDING"), 409);
    call(patch("/api/v1/services/" + service), Map.of("active", true), 200);
    long request =
        call(post("/api/v1/service-requests"), order(service, client, "PENDING"), 201)
            .get("id")
            .asLong();
    assertThat(
            call(get("/api/v1/users/" + client + "/service-requests"), null, 200)
                .get("totalElements")
                .asLong())
        .isEqualTo(1);
    assertThat(
            call(get("/api/v1/service-requests?status=PENDING"), null, 200).get("content").size())
        .isEqualTo(1);
    call(patch("/api/v1/service-requests/" + request), Map.of("totalPrice", 1), 400);
    call(patch("/api/v1/service-requests/" + request), Map.of("status", "COMPLETED"), 409);
    for (String state : new String[] {"ACCEPTED", "IN_PROGRESS", "COMPLETED"})
      call(patch("/api/v1/service-requests/" + request), Map.of("status", state), 200);
    long review =
        call(
                post("/api/v1/reviews"),
                Map.of("requestId", request, "reviewerId", client, "rating", 5),
                201)
            .get("id")
            .asLong();
    call(patch("/api/v1/reviews/" + review), Map.of("rating", 4), 200);
    call(patch("/api/v1/reviews/" + review), Map.of("rating", 0), 400);
    call(patch("/api/v1/reviews/" + review), Map.of("reviewerId", provider), 409);
    assertThat(
            call(get("/api/v1/services/" + service + "/reviews"), null, 200)
                .at("/content/0/rating")
                .asInt())
        .isEqualTo(4);
    call(get("/api/v1/services/999999/reviews"), null, 404);
    call(get("/api/v1/users/999999/service-requests"), null, 404);
    for (String resource : new String[] {"users", "services", "service-requests", "reviews"})
      call(patch("/api/v1/" + resource + "/999999"), Map.of(), 404);
  }

  Map<String, Object> provider(String email) {
    var data = new java.util.HashMap<>(user(email));
    data.put("role", "PROVIDER");
    return data;
  }

  JsonNode call(MockHttpServletRequestBuilder request, Object body, int status) throws Exception {
    if (body != null)
      request.contentType("application/json").content(json.writeValueAsString(body));
    String content =
        mvc.perform(request)
            .andExpect(status().is(status))
            .andReturn()
            .getResponse()
            .getContentAsString();
    return content.isEmpty() ? json.nullNode() : json.readTree(content);
  }

  Map<String, Object> user(String email) {
    return Map.of(
        "fullName",
        "Maria Silva",
        "email",
        email,
        "password",
        "senha12345",
        "active",
        true,
        "role",
        "CLIENT");
  }

  Map<String, Object> offering(long provider) {
    return Map.of(
        "title",
        "Manutenção",
        "description",
        "Diagnóstico",
        "price",
        150,
        "category",
        "TECNOLOGIA",
        "providerId",
        provider,
        "active",
        true);
  }

  Map<String, Object> order(long service, long client, String status) {
    return Map.of(
        "serviceId", service, "clientId", client, "status", status, "notes", "Visita técnica");
  }

  @Test
  void fullCrudAndBusinessRules() throws Exception {
    long provider =
        call(post("/api/v1/users"), provider("provider@example.com"), 201).get("id").asLong();
    long client = call(post("/api/v1/users"), user("client@example.com"), 201).get("id").asLong();
    JsonNode person = call(get("/api/v1/users/" + provider), null, 200);
    assertThat(person.has("password")).isFalse();
    assertThat(person.has("passwordHash")).isFalse();
    call(post("/api/v1/users"), user("PROVIDER@example.com"), 409);
    call(put("/api/v1/users/" + client), user("client.updated@example.com"), 200);
    long service = call(post("/api/v1/services"), offering(provider), 201).get("id").asLong();
    call(put("/api/v1/services/" + service), offering(provider), 200);
    assertThat(
            call(get("/api/v1/users/" + provider + "/services"), null, 200).get("content").size())
        .isEqualTo(1);
    call(delete("/api/v1/users/" + provider), null, 409);
    call(post("/api/v1/service-requests"), order(service, provider, "PENDING"), 409);
    long request =
        call(post("/api/v1/service-requests"), order(service, client, "PENDING"), 201)
            .get("id")
            .asLong();
    Map<String, Object> review =
        Map.of("requestId", request, "reviewerId", client, "rating", 5, "comment", "Excelente");
    call(post("/api/v1/reviews"), review, 409);
    call(put("/api/v1/service-requests/" + request), order(service, client, "COMPLETED"), 409);
    for (String state : new String[] {"ACCEPTED", "IN_PROGRESS", "COMPLETED"})
      call(put("/api/v1/service-requests/" + request), order(service, client, state), 200);
    Map<String, Object> newPrice = new java.util.HashMap<>(offering(provider));
    newPrice.put("price", 200);
    call(put("/api/v1/services/" + service), newPrice, 200);
    assertThat(
            call(get("/api/v1/service-requests/" + request), null, 200)
                .get("totalPrice")
                .decimalValue())
        .isEqualByComparingTo("150.00");
    call(
        post("/api/v1/reviews"),
        Map.of("requestId", request, "reviewerId", provider, "rating", 5),
        409);
    long rating = call(post("/api/v1/reviews"), review, 201).get("id").asLong();
    call(post("/api/v1/reviews"), review, 409);
    call(
        put("/api/v1/reviews/" + rating),
        Map.of("requestId", request, "reviewerId", client, "rating", 4, "comment", "Bom"),
        200);
    call(delete("/api/v1/service-requests/" + request), null, 409);
    call(delete("/api/v1/services/" + service), null, 409);
    for (String resource : new String[] {"users", "services", "service-requests", "reviews"})
      assertThat(call(get("/api/v1/" + resource), null, 200).get("content").isArray()).isTrue();
    call(get("/api/v1/reviews/" + rating), null, 200);
    call(delete("/api/v1/reviews/" + rating), null, 204);
    call(delete("/api/v1/service-requests/" + request), null, 204);
    call(delete("/api/v1/services/" + service), null, 204);
    call(delete("/api/v1/users/" + client), null, 204);
    call(delete("/api/v1/users/" + provider), null, 204);
    call(delete("/api/v1/users/" + provider), null, 404);
  }

  @Test
  void jwtLoginAndGraphqlQueries() throws Exception {
    long provider = call(post("/api/v1/users"), provider("graphql.provider@example.com"), 201)
        .get("id").asLong();
    call(post("/api/v1/services"), offering(provider), 201);

    JsonNode login = call(post("/api/v1/auth/login"),
        Map.of("email", "graphql.provider@example.com", "password", "senha12345"), 200);
    assertThat(login.get("accessToken").asText()).isNotBlank();
    assertThat(login.get("tokenType").asText()).isEqualTo("Bearer");
    call(post("/api/v1/auth/login"),
        Map.of("email", "graphql.provider@example.com", "password", "senha-errada"), 401);

    mvc.perform(post("/graphql").contentType("application/json")
            .content(json.writeValueAsString(Map.of("query", "query { services { id title price category providerId active } }"))))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.data.services[0].title").value("Manutenção"));
    mvc.perform(post("/graphql").contentType("application/json")
            .content(json.writeValueAsString(Map.of("query", "query { providers { id fullName email active } }"))))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.data.providers[0].email").value("graphql.provider@example.com"));
    mvc.perform(post("/graphql").contentType("application/json")
            .content(json.writeValueAsString(Map.of("query", "query { servicesByProvider(providerId: " + provider + ") { id title providerId } }"))))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.data.servicesByProvider[0].providerId").value(provider));

    long client = call(post("/api/v1/users"), user("graphql.client@example.com"), 201).get("id").asLong();
    JsonNode clientLogin = call(post("/api/v1/auth/login"),
        Map.of("email", "graphql.client@example.com", "password", "senha12345"), 200);
    String bookingQuery = "mutation { bookService(serviceId: " + call(get("/api/v1/services"), null, 200).at("/content/0/id").asLong() + ", notes: \"Agendamento de teste\") { id serviceId clientId status } }";
    mvc.perform(post("/graphql").header("Authorization", "Bearer " + clientLogin.get("accessToken").asText())
            .contentType("application/json").content(json.writeValueAsString(Map.of("query", bookingQuery))))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.data.bookService.clientId").value(client))
        .andExpect(jsonPath("$.data.bookService.status").value("PENDING"));
  }

  @Test
  void httpMethodAndContentNegotiation() throws Exception {
    mvc.perform(post("/api/v1/users/1")).andExpect(status().isMethodNotAllowed());
    mvc.perform(post("/api/v1/users").contentType("application/xml").content("<user/>"))
        .andExpect(status().isUnsupportedMediaType());
    mvc.perform(get("/api/v1/services").accept("application/xml"))
        .andExpect(status().isNotAcceptable());
  }

  @Test
  void validationAndDocumentation() throws Exception {
    mvc.perform(get("/api/hello"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value("OK"));
    for (String resource : new String[] {"users", "services", "service-requests", "reviews"}) {
      call(get("/api/v1/" + resource + "/999999"), null, 404);
      call(delete("/api/v1/" + resource + "/999999"), null, 404);
      call(post("/api/v1/" + resource), Map.of(), 400);
      call(get("/api/v1/" + resource + "/abc"), null, 400);
    }
    mvc.perform(post("/api/v1/users").contentType("application/json").content("{bad"))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.path").value("/api/v1/users"));
    call(post("/api/v1/reviews"), Map.of("requestId", 1, "reviewerId", 2, "rating", 6), 400);
    call(
        post("/api/v1/services"),
        Map.of(
            "title", "X", "price", -1, "category", "TECNOLOGIA", "providerId", 1, "active", true),
        400);
    mvc.perform(
            post("/api/v1/users")
                .contentType("application/json")
                .content(json.writeValueAsString(user("location@example.com"))))
        .andExpect(status().isCreated())
        .andExpect(header().exists("Location"));
    call(put("/api/v1/users/999999"), user("other@example.com"), 404);
    call(put("/api/v1/services/999999"), offering(1), 404);
    call(put("/api/v1/service-requests/999999"), order(1, 2, "PENDING"), 404);
    call(put("/api/v1/reviews/999999"), Map.of("requestId", 1, "reviewerId", 2, "rating", 5), 404);
    JsonNode docs = call(get("/v3/api-docs"), null, 200);
    assertThat(docs.get("paths").size()).isEqualTo(14);
    for (String resource : new String[] {"users", "services", "service-requests", "reviews"}) {
      assertThat(
              docs.at("/paths/" + ("/api/v1/" + resource).replace("/", "~1") + "/post/responses")
                  .has("201"))
          .isTrue();
    }
    assertThat(docs.at("/components/securitySchemes/bearerAuth/scheme").asText())
        .isEqualTo("bearer");
    assertThat(docs.has("security")).isFalse();
    assertThat(docs.at("/paths/~1api~1v1~1users/post/responses").has("404")).isFalse();
    assertThat(docs.at("/paths/~1api~1v1~1users~1{id}/get/responses").has("409")).isFalse();
    assertThat(docs.at("/paths/~1api~1v1~1reviews~1{id}/delete/responses").has("409")).isFalse();
    assertThat(docs.at("/paths/~1api~1v1~1service-requests/post/description").asText())
        .contains("totalPrice");
    java.util.Set<String> operationIds = new java.util.HashSet<>();
    docs.get("paths")
        .forEach(
            path ->
                path.forEach(
                    operation -> {
                      assertThat(operationIds.add(operation.get("operationId").asText())).isTrue();
                      assertThat(operation.get("description").asText()).isNotBlank();
                    }));
    assertThat(operationIds).hasSize(30);

    mvc.perform(get("/swagger-ui.html")).andExpect(status().is3xxRedirection());
  }
}
