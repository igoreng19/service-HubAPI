package com.servicehub;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.servicehub.service.ServiceOfferingService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import com.servicehub.controller.ServiceOfferingController;

@WebMvcTest(ServiceOfferingController.class)
@AutoConfigureMockMvc(addFilters = false)
class ServiceOfferingControllerWebTest {
  @Autowired MockMvc mvc;
  @MockBean ServiceOfferingService service;

  @Test
  void deveRetornar400QuandoPayloadNaoAtendeValidacao() throws Exception {
    mvc.perform(post("/api/v1/services")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{}"))
        .andExpect(status().isBadRequest());
  }
}
