package com.servicehub;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

import com.servicehub.dto.ServiceOfferingInput;
import com.servicehub.exception.ApiException;
import com.servicehub.model.ServiceCategory;
import com.servicehub.model.User;
import com.servicehub.model.UserRole;
import com.servicehub.repository.ReviewRepository;
import com.servicehub.repository.ServiceOfferingRepository;
import com.servicehub.repository.ServiceRequestRepository;
import com.servicehub.repository.UserRepository;
import com.servicehub.service.PatchSupport;
import com.servicehub.service.ServiceOfferingService;
import java.math.BigDecimal;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ServiceOfferingServiceTest {
  @Mock UserRepository users;
  @Mock ServiceOfferingRepository offerings;
  @Mock ServiceRequestRepository requests;
  @Mock PatchSupport patches;
  @InjectMocks ServiceOfferingService service;

  @Test
  void deveRejeitarCadastroQuandoUsuarioNaoForPrestador() {
    User client = new User();
    client.setId(7L); client.setRole(UserRole.CLIENT); client.setActive(true);
    when(users.findById(7L)).thenReturn(Optional.of(client));
    var input = new ServiceOfferingInput("Reparo", "Descrição", new BigDecimal("50.00"),
        ServiceCategory.TECNOLOGIA, 7L, true);

    assertThatThrownBy(() -> service.create(input))
        .isInstanceOf(ApiException.class)
        .hasMessageContaining("PROVIDER");
    verify(offerings, never()).saveAndFlush(any());
  }

  @Test
  void deveRejeitarCadastroQuandoPrestadorEstiverInativo() {
    User provider = new User();
    provider.setId(8L); provider.setRole(UserRole.PROVIDER); provider.setActive(false);
    when(users.findById(8L)).thenReturn(Optional.of(provider));
    var input = new ServiceOfferingInput("Reparo", "Descrição", new BigDecimal("50.00"),
        ServiceCategory.TECNOLOGIA, 8L, true);

    assertThatThrownBy(() -> service.create(input))
        .isInstanceOf(ApiException.class)
        .hasMessageContaining("inativo");
    verify(offerings, never()).saveAndFlush(any());
  }
}
