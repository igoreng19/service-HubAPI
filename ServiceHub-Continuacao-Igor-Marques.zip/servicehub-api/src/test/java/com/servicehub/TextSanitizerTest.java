package com.servicehub;

import static org.assertj.core.api.Assertions.assertThat;

import com.servicehub.service.TextSanitizer;
import org.junit.jupiter.api.Test;

class TextSanitizerTest {
  @Test
  void deveEscaparHtmlEmTextoLivre() {
    assertThat(TextSanitizer.plainText(" <script>alert('x')</script> "))
        .isEqualTo("&lt;script&gt;alert('x')&lt;/script&gt;");
  }

  @Test
  void devePreservarNuloETextoComum() {
    assertThat(TextSanitizer.plainText(null)).isNull();
    assertThat(TextSanitizer.plainText("  Serviço seguro  ")).isEqualTo("Serviço seguro");
  }
}
